# CUDA 单卡终端操作

本次由用户在终端完成全部服务器操作。上传包包含已补齐的模型代码、现有自检、新增回归检查、单卡 CUDA 入口和短训数据转换工具，不包含密码或私钥。只使用用户选定的一张 GPU，不运行 torchrun 多进程训练。

# Windows 上传与登录

在自己电脑的 PowerShell 执行：

```powershell
scp "D:\课程\智能计算系统\实验二\交付包\lab2-4090-20261103.tar.gz" cly@114.212.190.52:~/
ssh cly@114.212.190.52
```

两条命令都可能要求输入密码，输入时不显示字符，回车即可；不要把密码写进命令。第一次使用系统 SSH 时可能出现主机指纹确认，确认目标为实验室服务器后再接受。

# 服务器解压

以下命令都在 SSH 登录后的 Linux 终端执行。使用新的项目目录，避免覆盖其他作业。

```bash
mkdir "$HOME/aics-lab2-20261103"
tar -xzf "$HOME/lab2-4090-20261103.tar.gz" -C "$HOME/aics-lab2-20261103"
cd "$HOME/aics-lab2-20261103/assign"
pwd
df -h .
```

如果项目目录已经存在，先换一个新目录名，后续命令保持一致。

# 选择一张 GPU

先查看各卡状态：

```bash
nvidia-smi --query-gpu=index,uuid,name,memory.used,memory.total,utilization.gpu --format=csv
```

选择自己获准使用且空闲的卡。建议使用该行完整 UUID，避免物理编号和 CUDA 编号的映射混淆：

```bash
export GPU_ID=GPU-替换为选中卡的完整UUID
export CUDA_DEVICE_ORDER=PCI_BUS_ID
export CUDA_VISIBLE_DEVICES="$GPU_ID"
```

上面的 UUID 是需要替换的占位内容。例如也可以使用编号 `export GPU_ID=3`，前提是编号 3 是自己选定的空闲卡。不要填写列表。脚本只接受一个编号或完整 UUID，并要求 torch.cuda.device_count() 等于 1。

程序里的 cuda:0 是当前唯一可见的卡，不表示一定占用了服务器物理编号 0。nvidia-smi 通常仍显示服务器所有卡；它的显示范围不代表 Python 训练进程能使用所有卡。

# 准备 Python 环境

先确认当前 Python 已有可用 CUDA PyTorch。如果管理员提供了 conda 环境，应先进入那个环境。

```bash
python3 -c "import sys, torch; print(sys.version); print(torch.__version__, torch.version.cuda); print('CUDA available:', torch.cuda.is_available()); print('visible GPUs:', torch.cuda.device_count()); assert torch.cuda.is_available(); assert torch.cuda.device_count() == 1; print(torch.cuda.get_device_name(0))"
```

要求 Python 至少 3.10，使用支持 RMSNorm 和 SDPA enable_gqa 的 PyTorch（建议已有的 2.5 或更新版本）。如果这条命令失败，或显示 CPU 版 PyTorch，先保留输出用于选择匹配的环境；不要在共享系统中直接覆盖安装 torch 或修改驱动。

检查通过后，创建只属于本项目、可继承现有 PyTorch 的环境：

```bash
python3 -m venv --system-site-packages .venv
source .venv/bin/activate
python -m pip install -r requirements-dev.txt
```

如果系统没有 venv 或已有环境无法继承，请回传具体错误；本步骤不需要 sudo，也不安装 torch-npu 或外部 FlashAttention 包。

# 第一次短训

先把随包的公版小说转换为 parquet。此命令只需执行一次；已生成时直接复用，不必覆盖。

```bash
python scripts/prepare_smoke_data.py
export NANOCHAT_BASE_DIR="$PWD/outputs/cuda"
export TAG="d4-cuda-smoke-$(date +%Y%m%d-%H%M%S)"
bash runs/train_cuda.sh smoke
```

入口依次检查单卡、bf16、数据字段和 batch 配置，然后在 CPU 跑自检、准备词表与 token_bytes，最后在选定 GPU 上训练。CPU 检查会临时隐藏全部 GPU，不会占用其他卡。

默认设置为 d4、seq=512、单卡 batch=8、累计 batch=32768 token、50 个优化步骤；验证发生在 0、25、50 步，每次 65536 token，保存点为第 25 和第 50 步。训练目标量是 1638400 token，不是正式的高质量模型训练预算。模式固定为 SDPA、原生 RMSNorm、关闭 VE、bf16、eager；使用一条 Python 进程，wandb 关闭。

正常输出应包含 Visible GPUs=1、所选 RTX 4090、验证 BPB，以及 step、loss、dt、tok/sec。第一步可能包含初始化开销，看稳定区间而不是最快一步。完成后模型位于：

```text
outputs/cuda/base_checkpoints/<TAG>/
```

每次运行自动创建带时间的日志，位于 outputs/cuda/logs。终端仍在运行时不要按 Ctrl+C；第一轮短训建议保持连接。把单卡检查、几行稳定步骤、最终验证 BPB 和是否正常退出的结果回传，以便核算后续训练量。脚手架现有 MFU 的理论峰值口径还需核对，本轮先使用真实 tok/sec、时间与显存，不将该 MFU 直接写作最终结论。

# 短训后验证续写

在同一个终端，保留先前设置的 GPU_ID、CUDA_VISIBLE_DEVICES、TAG 和 NANOCHAT_BASE_DIR，执行：

```bash
export NANOCHAT_DISABLE_VE=1
export NANOCHAT_ATTN_IMPL=sdpa
export NANOCHAT_RMSNORM_IMPL=native
export NANOCHAT_DTYPE=bfloat16
export NANOCHAT_DISABLE_COMPILE=1
python -m scripts.chat_cli --device-type=cuda -i base -g "$TAG" -p "那少年提剑立在崖边，" -t 0.6 -k 40
```

短训样例可能不通顺，此时验收重点是 checkpoint 能加载、推理正常、没有精度或维度错误。正式模型质量需在正式训练后另行评测。VE 开关必须与训练一致；不能因为切换终端而丢失这些环境设置。

# 正式数据与正式训练

先用短训吞吐核算预算，再开始长训。公版短训语料不作为正式 scaling 研究的数据。

```bash
python scripts/fetch_box_data.py --only climbmix --dest ../downloads --extract-to ../datasets
find ../datasets -type f -name '*.parquet' -print -quit
export NANOCHAT_DATA_DIR="$(cd ../datasets/base_data_climbmix && pwd)"
export TAG="d8-cuda-base-$(date +%Y%m%d-%H%M%S)"
DEPTH=8 ITERS=1024 bash runs/train_cuda.sh train
```

课程包解压目录若不同，按 find 的结果修改 NANOCHAT_DATA_DIR；它必须直接包含 parquet 分片，且分片有 text 列。脚本会打印按排序选出的验证分片，需确认与数据包划分一致。

上面的正式训练为 1024 步、33554432 token，是预算起点，不是充分训练保证。若需要比较 d4、d6、d8，依次运行，每次改 DEPTH 和唯一 TAG；不要并发启动多个模型。更换模型规模仍只使用同一张选定 GPU。

正式训练会每 256 步评估 524288 token，每 128 步保存。先观察实际速度和保存开销，再调整训练总量与保存频率。显存不足时降低 DEVICE_BATCH，例如 DEVICE_BATCH=4；有效总 batch 仍固定 32768，并保持可以被 DEVICE_BATCH×SEQ 整除。

正式长训建议使用已有 tmux。若它可用，在启动前运行 tmux new -s aics-lab2，并在会话中激活 .venv、进入项目目录、重新设置单卡及数据环境变量后执行训练。Ctrl+B 后按 D 只是离开会话；使用 tmux attach -t aics-lab2 返回。不要为此修改服务器系统软件。

# 恢复与下载记录

训练中断后，使用相同 TAG、模型、数据、batch、精度和原计划总步数，将 RESUME_STEP 设置成实际存在的保存点：

```bash
TAG=实际原模型标签 RESUME_STEP=实际保存步数 DEPTH=原深度 ITERS=原总步数 bash runs/train_cuda.sh train
```

RESUME_STEP 不会从零重新计数；ITERS 是原计划的累计总步数。本入口的 resume 用于中断恢复；增加训练预算或改变阶段应单独讨论学习率调度，不能默认把续训等同于原计划恢复。

在自己电脑的新 PowerShell 窗口下载日志，可将目标本地目录换成自己选择的位置：

```powershell
scp -r cly@114.212.190.52:~/aics-lab2-20261103/assign/outputs/cuda/logs "D:\课程\智能计算系统\实验二\交付包\服务器日志"
```

日志和结果明确标注 RTX 4090；NPU 的数值与性能实测仍需单独完成或按老师认可的替代方案处理。

# 本地验证记录

新增入口通过 Bash 语法检查，GPU_ID=0,1 被拒绝；原自检为 13 通过、1 因无 NPU 跳过、0 失败，8 项回归全部通过。转换随包语料得到 2952 个训练块和 697 个验证块，最后一部书完整留作验证。CPU bf16 加 MuonAdamW 的 3 步检查 loss 为 4.203486、3.586775、2.624765。

这些是本地结果，未在服务器执行命令，未验证 CUDA 训练速度。上传包不含训练产物；第一次 GPU 短训由用户按以上流程完成。
