#!/usr/bin/env bash
# CANNLab single-visible-NPU baseline. Run from assign; no torchrun required.
set -euo pipefail
cd "$(dirname "$0")/.."
PYTHON="${PYTHON:-python3}"
if [[ -d "$PWD/.python-packages" ]]; then
    export PYTHONPATH="$PWD/.python-packages${PYTHONPATH:+:$PYTHONPATH}"
fi
DEPTH="${DEPTH:-8}"
ITERS="${ITERS:-50}"
DEVICE_BATCH="${DEVICE_BATCH:-8}"
TAG="${TAG:-d${DEPTH}-npu-smoke-$(date +%Y%m%d-%H%M%S)}"
export NANOCHAT_BASE_DIR="${NANOCHAT_BASE_DIR:-$PWD/outputs/npu}"
export NANOCHAT_DATA_DIR="${NANOCHAT_DATA_DIR:-$PWD/data/smoke_parquet}"
export NANOCHAT_DTYPE=bfloat16
export NANOCHAT_ATTN_IMPL=sdpa
export NANOCHAT_RMSNORM_IMPL=native
export NANOCHAT_DISABLE_VE=1
export NANOCHAT_DISABLE_COMPILE=1
export NANOCHAT_ENFORCE_EAGER=1
export OMP_NUM_THREADS=2
export PYTHONUNBUFFERED=1
export PYTHONUTF8=1
unset RANK LOCAL_RANK WORLD_SIZE LOCAL_WORLD_SIZE MASTER_ADDR MASTER_PORT

if [[ ! "$TAG" =~ ^[A-Za-z0-9_.-]+$ || "$TAG" == "." || "$TAG" == ".." ]]; then
    echo "TAG must be a simple name" >&2; exit 1
fi
if [[ -e "$NANOCHAT_BASE_DIR/base_checkpoints/$TAG" ]]; then
    echo "TAG already exists; choose a new tag" >&2; exit 1
fi
mkdir -p "$NANOCHAT_BASE_DIR/logs" "$NANOCHAT_BASE_DIR/tokenizer"
# The visible device is already restricted by CANNLab. Do not remap physical NPU 6.
LOG="$NANOCHAT_BASE_DIR/logs/$TAG.log"
{
    echo "NPU baseline: $TAG depth=$DEPTH steps=$ITERS batch=$DEVICE_BATCH seq=512 total_batch=32768"
    echo "data=$NANOCHAT_DATA_DIR outputs=$NANOCHAT_BASE_DIR"
    "$PYTHON" - <<'PY'
import torch, torch_npu
print('torch:', torch.__version__, 'torch_npu:', torch_npu.__version__)
assert torch.npu.is_available(), 'NPU unavailable'
assert torch.npu.device_count() == 1, 'Exactly one NPU must be visible'
torch.npu.set_device(0)
x = torch.ones((16, 16), device='npu:0', dtype=torch.bfloat16)
y = x @ x
torch.npu.synchronize()
assert y.float().sum().item() == 4096
print('One NPU:', torch.npu.get_device_name(0), 'bf16 matmul OK')
PY
    "$PYTHON" - <<'PY'
from pathlib import Path
import os
import pyarrow.parquet as pq
files = sorted(Path(os.environ['NANOCHAT_DATA_DIR']).glob('*.parquet'))
assert len(files) >= 2, 'Need at least one train and one last validation shard'
assert all(pq.ParquetFile(f).metadata.num_rows > 0 and 'text' in pq.ParquetFile(f).schema.names for f in files)
print('Train shards:', len(files)-1, 'validation:', files[-1].name)
PY
    if [[ ! -f "$NANOCHAT_BASE_DIR/tokenizer/tokenizer.pkl" ]]; then
        cp tokenizer/tokenizer.pkl "$NANOCHAT_BASE_DIR/tokenizer/tokenizer.pkl"
    fi
    if [[ ! -f "$NANOCHAT_BASE_DIR/tokenizer/token_bytes.pt" ]]; then
        "$PYTHON" scripts/make_token_bytes.py
    fi
    "$PYTHON" -u -m scripts.base_train \
        --device-type=npu --enforce-eager --run=dummy \
        --depth="$DEPTH" --max-seq-len=512 --window-pattern=SSSL \
        --device-batch-size="$DEVICE_BATCH" --total-batch-size=32768 \
        --num-iterations="$ITERS" --warmup-steps=5 \
        --eval-every=25 --eval-tokens=65536 --save-every=25 \
        --sample-every=-1 --model-tag="$TAG"
    echo "NPU BASELINE FINISHED: $TAG"
} 2>&1 | tee "$LOG"
