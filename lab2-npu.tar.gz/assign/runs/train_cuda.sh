#!/usr/bin/env bash
# One explicitly selected GPU, one Python process. No torchrun or package installation.
set -euo pipefail

REPO="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO"
MODE="${1:-smoke}"
if [[ "$MODE" != smoke && "$MODE" != train ]]; then
    echo "Usage: GPU_ID=<index-or-UUID> bash runs/train_cuda.sh smoke|train" >&2
    exit 2
fi
if [[ ! "${GPU_ID:-}" =~ ^([0-7]|GPU-[[:xdigit:]-]+)$ ]]; then
    echo "Set GPU_ID to ONE permitted, idle GPU index (0-7) or full GPU UUID. Lists are rejected." >&2
    exit 2
fi
export CUDA_DEVICE_ORDER=PCI_BUS_ID
export CUDA_VISIBLE_DEVICES="$GPU_ID"
unset RANK LOCAL_RANK WORLD_SIZE LOCAL_WORLD_SIZE MASTER_ADDR MASTER_PORT
export NANOCHAT_ATTN_IMPL=sdpa
export NANOCHAT_RMSNORM_IMPL=native
export NANOCHAT_DISABLE_VE=1
export NANOCHAT_DTYPE=bfloat16
export NANOCHAT_DISABLE_COMPILE=1
export NANOCHAT_ENFORCE_EAGER=1
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-2}"
export TOKENIZERS_PARALLELISM=false
export PYTHONUNBUFFERED=1
export PYTHONUTF8=1
export NANOCHAT_BASE_DIR="${NANOCHAT_BASE_DIR:-$REPO/outputs/cuda}"

if [[ "$MODE" == smoke ]]; then
    DEPTH="${DEPTH:-4}"
    ITERS="${ITERS:-50}"
    EVAL_EVERY="${EVAL_EVERY:-25}"
    EVAL_TOKENS="${EVAL_TOKENS:-65536}"
    SAVE_EVERY="${SAVE_EVERY:-25}"
    WARMUP="${WARMUP:-5}"
    export NANOCHAT_DATA_DIR="${NANOCHAT_DATA_DIR:-$REPO/data/smoke_parquet}"
else
    DEPTH="${DEPTH:-8}"
    ITERS="${ITERS:-1024}"
    EVAL_EVERY="${EVAL_EVERY:-256}"
    EVAL_TOKENS="${EVAL_TOKENS:-524288}"
    SAVE_EVERY="${SAVE_EVERY:-128}"
    WARMUP="${WARMUP:-40}"
    if [[ -z "${NANOCHAT_DATA_DIR:-}" ]]; then
        echo "Formal training requires NANOCHAT_DATA_DIR pointing to prepared course parquet data." >&2
        exit 2
    fi
fi
SEQ="${SEQ:-512}"
DEVICE_BATCH="${DEVICE_BATCH:-8}"
TOTAL_BATCH="${TOTAL_BATCH:-32768}"
TAG="${TAG:-d${DEPTH}-cuda-${MODE}-$(date +%Y%m%d-%H%M%S)}"
RESUME_STEP="${RESUME_STEP:--1}"
export NANOCHAT_SEQ="$SEQ" NANOCHAT_DEVICE_BATCH="$DEVICE_BATCH" NANOCHAT_TOTAL_BATCH="$TOTAL_BATCH"
mkdir -p "$NANOCHAT_BASE_DIR/logs"
LOG="$NANOCHAT_BASE_DIR/logs/${TAG}-$(date +%Y%m%d-%H%M%S).log"
exec > >(tee -a "$LOG") 2>&1
echo "Mode=$MODE selected GPU=$GPU_ID model tag=$TAG"
echo "Data=$NANOCHAT_DATA_DIR"
echo "Outputs=$NANOCHAT_BASE_DIR log=$LOG"
if [[ "$RESUME_STEP" == -1 && -d "$NANOCHAT_BASE_DIR/base_checkpoints/$TAG" ]]; then
    echo "Model tag already exists. Choose a new TAG or explicitly set RESUME_STEP." >&2
    exit 2
fi

python - <<'PY'
import os
from pathlib import Path
import torch
import pyarrow.parquet as pq
assert torch.cuda.is_available(), "CUDA unavailable: use a CUDA-enabled PyTorch environment"
assert torch.cuda.device_count() == 1, "Exactly ONE CUDA device must be visible"
assert torch.cuda.is_bf16_supported(), "Selected GPU/PyTorch does not support bf16"
p = torch.cuda.get_device_properties(0)
free, total = torch.cuda.mem_get_info(0)
print(f"torch={torch.__version__}, CUDA={torch.version.cuda}, GPU={p.name}")
print(f"Visible GPUs=1; free={free/2**30:.2f} GiB; total={total/2**30:.2f} GiB")
data = Path(os.environ['NANOCHAT_DATA_DIR'])
files = sorted(data.glob('*.parquet'))
assert len(files) >= 2, f"Need >=2 parquet shards (last is val), found {len(files)} in {data}"
for f in files:
    assert 'text' in pq.ParquetFile(f).schema.names, f"Missing text column: {f}"
print(f"Train shards={len(files)-1}; validation={files[-1].name}")
assert int(os.environ['NANOCHAT_TOTAL_BATCH']) % (int(os.environ['NANOCHAT_DEVICE_BATCH']) * int(os.environ['NANOCHAT_SEQ'])) == 0, "Total batch must be divisible by device_batch*seq"
PY

# These tests deliberately use CPU; they do not occupy any extra GPU.
CUDA_VISIBLE_DEVICES="" python scripts/selfcheck.py
CUDA_VISIBLE_DEVICES="" python -m unittest discover -s tests -v
mkdir -p "$NANOCHAT_BASE_DIR/tokenizer"
if [[ ! -f "$NANOCHAT_BASE_DIR/tokenizer/tokenizer.pkl" ]]; then
    cp tokenizer/tokenizer.pkl "$NANOCHAT_BASE_DIR/tokenizer/tokenizer.pkl"
fi
if [[ ! -f "$NANOCHAT_BASE_DIR/tokenizer/token_bytes.pt" ]]; then
    CUDA_VISIBLE_DEVICES="" python scripts/make_token_bytes.py
fi

python -m scripts.base_train \
    --device-type=cuda --enforce-eager --run=dummy \
    --depth="$DEPTH" --max-seq-len="$SEQ" --window-pattern=SSSL \
    --device-batch-size="$DEVICE_BATCH" --total-batch-size="$TOTAL_BATCH" \
    --num-iterations="$ITERS" --warmup-steps="$WARMUP" \
    --eval-every="$EVAL_EVERY" --eval-tokens="$EVAL_TOKENS" \
    --save-every="$SAVE_EVERY" --sample-every=-1 \
    --model-tag="$TAG" --resume-from-step="$RESUME_STEP"
echo "Finished. Model tag=$TAG; outputs=$NANOCHAT_BASE_DIR"
