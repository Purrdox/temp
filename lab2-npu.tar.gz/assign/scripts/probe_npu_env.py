#!/usr/bin/env python3
"""Inspect the existing cloud image; do not install packages or run training."""
import importlib.util
import json
import platform
import sys


def inspect():
    result = {"python": sys.version, "executable": sys.executable,
              "system": platform.system(), "architecture": platform.machine(),
              "dependencies_present": {name: importlib.util.find_spec(name) is not None
                                       for name in ("numpy", "pyarrow", "tiktoken", "psutil",
                                                    "requests", "filelock", "yaml")}}
    try:
        import torch
        result["torch"] = torch.__version__
        result["has_sdpa"] = hasattr(torch.nn.functional, "scaled_dot_product_attention")
    except Exception as error:
        result["torch_error"] = f"{type(error).__name__}: {error}"
        return result
    try:
        import torch_npu
        result["torch_npu"] = getattr(torch_npu, "__version__", "unknown")
        result["npu_available"] = torch.npu.is_available()
        result["visible_npu_count"] = torch.npu.device_count()
        result["fusion_attention_present"] = hasattr(torch_npu, "npu_fusion_attention")
        result["fused_rmsnorm_present"] = hasattr(torch_npu, "npu_rms_norm")
        if result["npu_available"] and result["visible_npu_count"]:
            result["first_visible_npu"] = torch.npu.get_device_name(0)
    except Exception as error:
        result["torch_npu_error"] = f"{type(error).__name__}: {error}"
    return result


if __name__ == "__main__":
    print(json.dumps(inspect(), ensure_ascii=False, indent=2))
