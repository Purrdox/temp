#!/usr/bin/env python3
"""Convert bundled public-domain books to book-disjoint smoke-test parquet."""
import argparse
import hashlib
import json
from pathlib import Path

import pyarrow as pa
import pyarrow.parquet as pq


def prepare(source_dir, output_dir, chunk_chars=1024):
    if chunk_chars < 64:
        raise ValueError("chunk_chars must be at least 64")
    source_dir, output_dir = Path(source_dir), Path(output_dir)
    books = sorted(source_dir.glob("*.txt"))
    if len(books) < 2:
        raise ValueError("Need at least two .txt books for a book-disjoint split")
    output_dir.mkdir(parents=True, exist_ok=True)
    names = ("00_train.parquet", "99_val.parquet", "manifest.json")
    if any((output_dir / name).exists() for name in names):
        raise FileExistsError(f"Prepared files already exist in {output_dir}; reuse them or choose a new output directory")
    rows = {"train": [], "val": []}
    records = []
    for book in books:
        raw = book.read_bytes()
        text = raw.decode("utf-8-sig").strip()
        split = "val" if book == books[-1] else "train"
        chunks = [text[i:i + chunk_chars] for i in range(0, len(text), chunk_chars)]
        rows[split].extend(chunk for chunk in chunks if chunk.strip())
        records.append({"book": book.name, "split": split, "sha256": hashlib.sha256(raw).hexdigest(),
                        "characters": len(text), "chunks": len(chunks)})
    if not all(rows.values()):
        raise ValueError("Both train and validation splits must be nonempty")
    for split, name in zip(("train", "val"), names):
        pq.write_table(pa.table({"text": rows[split]}), output_dir / name,
                       compression="zstd", row_group_size=128)
    manifest = {"purpose": "pipeline smoke test, not formal scaling results",
                "split_rule": "last sorted book held out entirely for validation",
                "chunk_chars": chunk_chars, "books": records,
                "train_rows": len(rows["train"]), "val_rows": len(rows["val"])}
    (output_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
    print(f"Prepared smoke data: {output_dir.resolve()}")
    return manifest


if __name__ == "__main__":
    repo = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-dir", type=Path, default=repo / "data" / "corpus")
    parser.add_argument("--output-dir", type=Path, default=repo / "data" / "smoke_parquet")
    parser.add_argument("--chunk-chars", type=int, default=1024)
    args = parser.parse_args()
    prepare(args.source_dir, args.output_dir, args.chunk_chars)
