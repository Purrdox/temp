#!/usr/bin/env python3
"""Single-GPU launcher for native Windows, using the invoking Python environment."""
import argparse
from datetime import datetime
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys


def main():
    repo = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=("smoke", "train"), default="smoke")
    parser.add_argument("--gpu", default="0", help="One GPU index or full GPU UUID")
    parser.add_argument("--depth", type=int)
    parser.add_argument("--steps", type=int)
    parser.add_argument("--device-batch", type=int, default=2)
    parser.add_argument("--seq", type=int, default=512)
    parser.add_argument("--total-batch", type=int, default=32768)
    parser.add_argument("--data-dir", type=Path)
    parser.add_argument("--output-dir", type=Path, default=repo / "outputs" / "4060")
    parser.add_argument("--tag")
    parser.add_argument("--eval-every", type=int)
    parser.add_argument("--save-every", type=int)
    args = parser.parse_args()
    if not re.fullmatch(r"(?:[0-7]|GPU-[a-fA-F0-9-]+)", args.gpu):
        parser.error("--gpu must select exactly one GPU, not a list")
    smoke = args.mode == "smoke"
    depth = args.depth if args.depth is not None else (4 if smoke else 8)
    steps = args.steps if args.steps is not None else (50 if smoke else 1024)
    if min(depth, steps, args.device_batch, args.seq, args.total_batch) <= 0:
        parser.error("Model and training sizes must be positive")
    if args.total_batch % (args.device_batch * args.seq):
        parser.error("total-batch must be divisible by device-batch*seq")
    eval_every = args.eval_every if args.eval_every is not None else (25 if smoke else 256)
    save_every = args.save_every if args.save_every is not None else (25 if smoke else 128)
    if min(eval_every, save_every) <= 0:
        parser.error("eval-every and save-every must be positive")
    if not smoke and args.data_dir is None:
        parser.error("Formal training requires --data-dir pointing to course parquet")
    data_dir = (args.data_dir or repo / "data" / "smoke_parquet").resolve()
    output_dir = args.output_dir.resolve()
    tag = args.tag or f"d{depth}-4060-{args.mode}-{datetime.now():%Y%m%d-%H%M%S}"
    if not re.fullmatch(r"[A-Za-z0-9_.-]+", tag) or tag in (".", ".."):
        parser.error("tag must be a simple model name without path separators")
    if (output_dir / "base_checkpoints" / tag).exists():
        parser.error("Model tag already exists; choose a new tag")
    log_dir = output_dir / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_path = log_dir / f"{tag}.log"
    env = os.environ.copy()
    for key in ("RANK", "LOCAL_RANK", "WORLD_SIZE", "LOCAL_WORLD_SIZE", "MASTER_ADDR", "MASTER_PORT"):
        env.pop(key, None)
    env.update({
        "CUDA_DEVICE_ORDER": "PCI_BUS_ID", "CUDA_VISIBLE_DEVICES": args.gpu,
        "NANOCHAT_DTYPE": "bfloat16", "NANOCHAT_ATTN_IMPL": "sdpa",
        "NANOCHAT_RMSNORM_IMPL": "native", "NANOCHAT_DISABLE_VE": "1",
        "NANOCHAT_DISABLE_COMPILE": "1", "NANOCHAT_ENFORCE_EAGER": "1",
        "NANOCHAT_BASE_DIR": str(output_dir), "NANOCHAT_DATA_DIR": str(data_dir),
        "OMP_NUM_THREADS": "2", "PYTHONUTF8": "1", "PYTHONUNBUFFERED": "1",
        "TOKENIZERS_PARALLELISM": "false",
    })
    cpu_env = dict(env, CUDA_VISIBLE_DEVICES="", NANOCHAT_DTYPE="float32")
    config = {"depth": depth, "steps": steps, "device_batch": args.device_batch,
              "seq": args.seq, "total_batch": args.total_batch,
              "gradient_accumulation": args.total_batch // (args.device_batch * args.seq),
              "gpu": args.gpu, "tag": tag, "mode": args.mode,
              "data_dir": str(data_dir), "output_dir": str(output_dir),
              "python": sys.executable, "dtype": "bfloat16", "attention": "sdpa",
              "value_embeddings": False, "compile": False,
              "eval_every": eval_every, "save_every": save_every,
              "eval_tokens": 65536 if smoke else 524288}
    (log_dir / f"{tag}.json").write_text(json.dumps(config, indent=2), encoding="utf-8")

    with log_path.open("w", encoding="utf-8", buffering=1) as log:
        def emit(message):
            print(message, flush=True)
            log.write(str(message) + "\n")

        def run(arguments, process_env):
            command = [sys.executable, "-u", "-X", "utf8", *arguments]
            emit("Running: " + subprocess.list2cmdline(command))
            with subprocess.Popen(command, cwd=repo, env=process_env, stdout=subprocess.PIPE,
                                  stderr=subprocess.STDOUT, text=True, encoding="utf-8",
                                  errors="replace", bufsize=1) as process:
                try:
                    for line in process.stdout:
                        print(line, end="", flush=True)
                        log.write(line)
                    code = process.wait()
                except KeyboardInterrupt:
                    process.terminate()
                    process.wait()
                    emit("Interrupted. Previously saved checkpoints are retained.")
                    raise
            if code:
                raise RuntimeError(f"Step failed with exit code {code}. See {log_path}")

        emit(json.dumps(config, indent=2))
        run(["-c", "import torch; "
             "print('torch:',torch.__version__,'CUDA:',torch.version.cuda); "
             "assert torch.cuda.is_available(), 'CUDA PyTorch is required; CPU build cannot train on GPU'; "
             "assert torch.cuda.device_count()==1, 'Exactly one GPU must be visible'; "
             "assert torch.cuda.is_bf16_supported(), 'bf16 unsupported'; "
             "print('Visible GPUs: 1; GPU:',torch.cuda.get_device_name(0)); "
             "print('Free/total GiB:',tuple(round(x/2**30,2) for x in torch.cuda.mem_get_info(0)))"], env)
        run(["scripts/selfcheck.py"], cpu_env)
        run(["-m", "unittest", "discover", "-s", "tests", "-v"], cpu_env)
        if smoke and not list(data_dir.glob("*.parquet")):
            run(["scripts/prepare_smoke_data.py", "--output-dir", str(data_dir)], cpu_env)
        run(["-c", "from pathlib import Path; import sys; import pyarrow.parquet as pq; "
             "files=sorted(Path(sys.argv[1]).glob('*.parquet')); "
             "assert len(files)>=2, 'Need train and validation parquet files'; "
             "assert all('text' in pq.ParquetFile(f).schema.names for f in files), 'Missing text column'; "
             "print('Train shards:',len(files)-1,'validation:',files[-1].name)", str(data_dir)], cpu_env)
        tokenizer_dir = output_dir / "tokenizer"
        tokenizer_dir.mkdir(parents=True, exist_ok=True)
        if not (tokenizer_dir / "tokenizer.pkl").exists():
            shutil.copy2(repo / "tokenizer" / "tokenizer.pkl", tokenizer_dir / "tokenizer.pkl")
        if not (tokenizer_dir / "token_bytes.pt").exists():
            run(["scripts/make_token_bytes.py"], cpu_env)
        run(["-m", "scripts.base_train", "--device-type=cuda", "--enforce-eager", "--run=dummy",
             f"--depth={depth}", f"--max-seq-len={args.seq}", "--window-pattern=SSSL",
             f"--device-batch-size={args.device_batch}", f"--total-batch-size={args.total_batch}",
             f"--num-iterations={steps}", f"--warmup-steps={min(5 if smoke else 40, max(1, steps // 4))}",
             f"--eval-every={eval_every}", f"--eval-tokens={65536 if smoke else 524288}",
             f"--save-every={save_every}", "--sample-every=-1", f"--model-tag={tag}"], env)
        emit(f"Finished. Model tag: {tag}")
        emit(f"Log: {log_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
