#!/usr/bin/env python3
"""Download verified course data, then train d8/d4/d6 sequentially on one GPU."""
import argparse
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re
import shutil
import statistics
import subprocess
import sys


REPO = Path(__file__).resolve().parents[1]
ARCHIVE_NAME = "base_data_climbmix.tar"


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def check_data(data_dir):
    """Match the course split convention, never accept the smoke dataset."""
    import pyarrow as pa
    import pyarrow.parquet as pq

    files = sorted(data_dir.glob("*.parquet"))
    train = [p for p in files if p.name.startswith("shard_train_")]
    val = [p for p in files if p.name.startswith("shard_val_")]
    if not train or len(val) != 1 or len(files) != len(train) + 1 or files[-1] != val[0]:
        raise ValueError(f"Expected shard_train_*.parquet + one last shard_val_*.parquet in {data_dir}; "
                         "smoke data is not accepted. No training started.")
    records = []
    for path in files:
        pf = pq.ParquetFile(path)
        if not pf.metadata.num_rows or "text" not in pf.schema_arrow.names:
            raise ValueError(f"Empty parquet or missing text: {path}")
        field_type = pf.schema_arrow.field("text").type
        if not (pa.types.is_string(field_type) or pa.types.is_large_string(field_type)):
            raise ValueError(f"Expected string text column: {path}")
        batch = next(pf.iter_batches(batch_size=8, columns=["text"]))
        if not any(isinstance(t, str) and t for t in batch.column(0).to_pylist()):
            raise ValueError(f"First text batch is empty: {path}")
        records.append({"name": path.name, "bytes": path.stat().st_size,
                        "rows": pf.metadata.num_rows,
                        "split": "validation" if path == val[0] else "train"})
    return records


def commands(python, data_dir, output_dir, prefix, steps, gpu):
    return [(d, f"d{d}-4060-course-{prefix}", [
        python, "-u", "-X", "utf8", str(REPO / "scripts" / "train_4060.py"),
        "--mode", "train", "--gpu", gpu, "--depth", str(d), "--steps", str(steps),
        "--device-batch", "2", "--seq", "512", "--total-batch", "32768",
        "--eval-every", "512", "--save-every", "512",
        "--data-dir", str(data_dir), "--output-dir", str(output_dir),
        "--tag", f"d{d}-4060-course-{prefix}",
    ]) for d in (8, 4, 6)]


def summarize(output_dir, tag, steps):
    log_path = output_dir / "logs" / f"{tag}.log"
    log = log_path.read_text(encoding="utf-8")
    evaluations = [{"step": int(s), "trained_tokens": int(s) * 32768, "bpb": float(b)}
                   for s, b in re.findall(r"Step (\d+) \| Validation bpb: ([0-9.]+)", log)]
    meta_path = output_dir / "base_checkpoints" / tag / f"meta_{steps:06d}.json"
    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    final_weights = meta_path.with_name(f"model_{steps:06d}.pt")
    optimizer = meta_path.with_name(f"optim_{steps:06d}_rank0.pt")
    if not final_weights.is_file() or not optimizer.is_file() or meta["step"] != steps:
        raise RuntimeError(f"Final checkpoint is incomplete: {tag}")
    if not evaluations or evaluations[-1]["step"] != steps:
        raise RuntimeError(f"Final evaluation missing: {tag}")
    params = re.search(r"^total\s*:\s*([0-9,]+)", log, re.MULTILINE)
    peak = re.search(r"Peak memory usage: ([0-9.]+)MiB", log)
    rates = [int(rate.replace(",", "")) for step, rate in
             re.findall(r"step (\d+)/\d+[^\n]*tok/sec: ([0-9,]+)", log) if int(step) >= 10]
    return {"model_tag": tag, "log": str(log_path), "checkpoint": str(final_weights),
            "model_config": meta["model_config"], "evaluations": evaluations,
            "parameters": int(params[1].replace(",", "")) if params else None,
            "median_train_tokens_per_second": statistics.median(rates) if rates else None,
            "torch_peak_allocated_mib": float(peak[1]) if peak else None,
            "trained_tokens": steps * 32768,
            "finished_at": datetime.now().isoformat(timespec="seconds")}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--steps", type=int, default=4096, help="Same horizon for all three models")
    parser.add_argument("--gpu", default="0")
    parser.add_argument("--data-dir", type=Path,
                        help="Existing course parquet directory; otherwise download automatically")
    parser.add_argument("--output-dir", type=Path, default=REPO / "outputs" / "4060")
    parser.add_argument("--dry-run", action="store_true", help="Print commands without download or training")
    args = parser.parse_args()
    if args.steps <= 0 or args.steps % 512:
        parser.error("steps must be a positive multiple of 512")
    if not re.fullmatch(r"(?:[0-7]|GPU-[a-fA-F0-9-]+)", args.gpu):
        parser.error("Select exactly one GPU")
    data_dir = (args.data_dir or REPO / "data" / "course" / "base_data_climbmix").resolve()
    output_dir = args.output_dir.resolve()
    prefix = datetime.now().strftime("%Y%m%d-%H%M%S")
    jobs = commands(sys.executable, data_dir, output_dir, prefix, args.steps, args.gpu)
    for depth, tag, command in jobs:
        print(f"d{depth}: {args.steps:,} updates, {args.steps * 32768:,} training tokens", flush=True)
        print(subprocess.list2cmdline(command), flush=True)
    if args.dry_run:
        print("DRY RUN: no download, no GPU access, no files created.")
        return 0

    output_dir.mkdir(parents=True, exist_ok=True)
    if shutil.disk_usage(output_dir).free < 20 * 2**30:
        raise RuntimeError("Need at least 20 GiB free for data and retained checkpoints")
    queue_dir = output_dir / "queues" / prefix
    queue_dir.mkdir(parents=True, exist_ok=False)
    sources = [*sorted((REPO / "nanochat").glob("*.py")),
               *sorted((REPO / "scripts").glob("*.py")), REPO / "tokenizer" / "tokenizer.pkl"]
    write_json(queue_dir / "plan.json", {
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "device": "CUDA single GPU; not Ascend NPU", "gpu": args.gpu,
        "data_dir": str(data_dir), "steps_per_model": args.steps,
        "training_tokens_per_model": args.steps * 32768, "seed": 42,
        "seq": 512, "total_batch": 32768, "device_batch": 2,
        "eval_tokens": 524288, "eval_every": 512, "save_every": 512,
        "jobs": [{"depth": d, "tag": t, "command": c} for d, t, c in jobs],
        "source_sha256": {str(p.relative_to(REPO)): hashlib.sha256(p.read_bytes()).hexdigest()
                          for p in sources},
    })
    if args.data_dir is None:
        # Download only. Verify successfully before permitting any extraction.
        from fetch_box_data import read_expected_sha256, sha256_of, extract_one
        packed = REPO / "data" / "packed"
        subprocess.run([sys.executable, "-u", "-X", "utf8",
                        str(REPO / "scripts" / "fetch_box_data.py"),
                        "--only", ARCHIVE_NAME, "--dest", str(packed), "--no-extract"],
                       cwd=REPO, check=True)
        archive = packed / ARCHIVE_NAME
        expected = read_expected_sha256(str(REPO / "data" / "manifests" / "packed_data.sha256"))
        if ARCHIVE_NAME not in expected or sha256_of(str(archive)) != expected[ARCHIVE_NAME]:
            raise RuntimeError("Course archive SHA-256 mismatch; no extraction or training")
        data_dir.parent.mkdir(parents=True, exist_ok=True)
        ok, message = extract_one(str(archive), str(data_dir.parent))
        print(message, flush=True)
        if not ok:
            raise RuntimeError(message)
        write_json(queue_dir / "archive.json", {"name": ARCHIVE_NAME,
                   "sha256": expected[ARCHIVE_NAME]})
    records = check_data(data_dir)
    write_json(queue_dir / "data.json", records)
    print(f"COURSE DATA READY: {len(records)-1} train shards + 1 held-out validation shard", flush=True)
    print(f"Queue records: {queue_dir}", flush=True)
    completed = []
    for depth, tag, command in jobs:
        print(f"\nSTART d{depth}: {datetime.now().isoformat(timespec='seconds')}", flush=True)
        subprocess.run(command, cwd=REPO, check=True)
        completed.append(summarize(output_dir, tag, args.steps))
        write_json(queue_dir / "results.json", completed)
    print(f"ALL THREE MODELS FINISHED. Results: {queue_dir / 'results.json'}", flush=True)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (RuntimeError, ValueError, OSError, subprocess.CalledProcessError) as error:
        print(f"QUEUE STOPPED: {error}. Existing checkpoints and logs are retained.", file=sys.stderr)
        raise SystemExit(1)
