"""
Engine for efficient inference of our models.

Everything works around token sequences:
- The user can send token sequences to the engine
- The engine returns the next token

Notes:
- The engine knows nothing about tokenization, it's purely token id sequences.

The whole thing is made as efficient as possible.
"""

import torch
import torch.nn.functional as F
import signal
import warnings
from contextlib import contextmanager
from collections import deque
from nanochat.common import compute_init, autodetect_device_type, COMPUTE_DTYPE

# -----------------------------------------------------------------------------
# Calculator tool helpers
@contextmanager
def timeout(duration, formula):
    def timeout_handler(signum, frame):
        raise Exception(f"'{formula}': timed out after {duration} seconds")

    signal.signal(signal.SIGALRM, timeout_handler)
    signal.alarm(duration)
    yield
    signal.alarm(0)

def eval_with_timeout(formula, max_time=3):
    try:
        with timeout(max_time, formula):
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", SyntaxWarning)
                return eval(formula, {"__builtins__": {}}, {})
    except Exception as e:
        signal.alarm(0)
        # print(f"Warning: Failed to eval {formula}, exception: {e}") # it's ok ignore wrong calculator usage
        return None

def use_calculator(expr):
    """
    Evaluate a Python expression safely.
    Supports both math expressions and string operations like .count()
    """
    # Remove commas from numbers
    expr = expr.replace(",", "")

    # Check if it's a pure math expression (old behavior)
    if all([x in "0123456789*+-/.() " for x in expr]):
        if "**" in expr:  # disallow power operator
            return None
        return eval_with_timeout(expr)

    # Check if it's a string operation we support
    # Allow: strings (single/double quotes), .count(), letters, numbers, spaces, parens
    allowed_chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'\"()._ "
    if not all([x in allowed_chars for x in expr]):
        return None

    # Disallow dangerous patterns
    dangerous_patterns = ['__', 'import', 'exec', 'eval', 'compile', 'open', 'file',
                         'input', 'raw_input', 'globals', 'locals', 'vars', 'dir',
                         'getattr', 'setattr', 'delattr', 'hasattr']
    expr_lower = expr.lower()
    if any(pattern in expr_lower for pattern in dangerous_patterns):
        return None

    # Only allow .count() method for now (can expand later)
    if '.count(' not in expr:
        return None

    # Evaluate with timeout
    return eval_with_timeout(expr)

# -----------------------------------------------------------------------------
class KVCache:
    """
    KV Cache designed for Flash Attention 3's flash_attn_with_kvcache API.

    Key differences from FA2-style cache:
    - Tensors are (B, T, H, D) not (B, H, T, D)
    - FA3 updates the cache in-place during flash_attn_with_kvcache
    - Position tracked per batch element via cache_seqlens tensor
    """

    def __init__(self, batch_size, num_heads, seq_len, head_dim, num_layers, device, dtype):
        self.batch_size = batch_size
        self.max_seq_len = seq_len
        self.n_layers = num_layers
        self.n_heads = num_heads
        self.head_dim = head_dim
        # Pre-allocate cache tensors: (n_layers, B, T, H, D)
        self.k_cache = torch.zeros(num_layers, batch_size, seq_len, num_heads, head_dim, device=device, dtype=dtype)
        self.v_cache = torch.zeros(num_layers, batch_size, seq_len, num_heads, head_dim, device=device, dtype=dtype)
        # Current sequence length per batch element (FA3 needs int32)
        self.cache_seqlens = torch.zeros(batch_size, dtype=torch.int32, device=device)
        # Previous token's normalized embedding for smear (set by model forward pass)
        self.prev_embedding = None

    def reset(self):
        """Reset cache to empty state."""
        self.cache_seqlens.zero_()
        self.prev_embedding = None

    def get_pos(self):
        """Get current position (assumes all batch elements at same position)."""
        return self.cache_seqlens[0].item()

    def get_layer_cache(self, layer_idx):
        """Return (k_cache, v_cache) views for a specific layer."""
        return self.k_cache[layer_idx], self.v_cache[layer_idx]

    def advance(self, num_tokens):
        """Advance the cache position by num_tokens."""
        self.cache_seqlens += num_tokens

    def prefill(self, other):
        """
        Copy cached KV from another cache into this one.
        Used when we do batch=1 prefill and then want to generate multiple samples in parallel.
        """
        # ---- 核心任务 6：把一次前向的 KV cache 复制成 num_samples 份 ------------
        # 批量采样时，同一段 prompt 的 KV cache 只需算一次，然后**复制**成
        # num_samples 份各自继续生成。不做这个优化，num_samples 条样本就要
        # 各自重算一遍 prompt —— 这是"批量推理为什么快"的关键点之一。
        #
        # 步骤：
        #   1) 把自己的 k/v cache 沿 **batch 维（dim=0）** 重复 num_samples 次
        #   2) pos 也复制一份
        #
        # 提示：
        #   * torch.repeat_interleave 或 .repeat 都行，注意维度顺序
        #   * 复制的是**已经算好的** KV，所以这一步不做任何矩阵运算（很便宜）
        #   * 复制后各样本共享同一段 prompt 的 cache，但后续写入互不影响
        assert not bool(self.cache_seqlens.any()), "目标 cache 必须为空"
        assert self.batch_size % other.batch_size == 0, "目标 batch 必须是源 batch 的整数倍"
        assert (self.n_layers, self.n_heads, self.head_dim) == (other.n_layers, other.n_heads, other.head_dim)
        pos = other.get_pos()
        assert bool((other.cache_seqlens == pos).all()), "源 cache 的各行长度必须一致"
        assert pos <= self.max_seq_len, "目标 cache 容量不足"
        repeats = self.batch_size // other.batch_size
        self.k_cache[:, :, :pos].copy_(other.k_cache[:, :, :pos].repeat_interleave(repeats, dim=1))
        self.v_cache[:, :, :pos].copy_(other.v_cache[:, :, :pos].repeat_interleave(repeats, dim=1))
        self.cache_seqlens.copy_(other.cache_seqlens.repeat_interleave(repeats))
        if other.prev_embedding is not None:
            self.prev_embedding = other.prev_embedding.repeat_interleave(repeats, dim=0).clone()
# -----------------------------------------------------------------------------
@torch.inference_mode()
def sample_next_token(logits, rng, temperature=1.0, top_k=None):
    """Sample a single next token from given logits of shape (B, vocab_size). Returns (B, 1)."""
    # ---- 基础任务 4：采样 next token ----------------------------------------
    # 输入 logits: (B, V)，返回每行采到的 token id: (B,)
    #
    # 步骤：
    #   1) temperature == 0 时**不采样**，直接 argmax（贪心、可复现）
    #   2) 否则 logits = logits / temperature
    #   3) top_k 若给出且 > 0：把**小于第 k 大**的 logits 置为 -inf。
    #      用 torch.topk(logits, k, dim=-1) 拿阈值即可，不必全排序
    #   4) softmax 后按概率多项式采样：torch.multinomial(probs, 1, generator=rng)
    #
    # 提示：
    #   * rng 是调用方传进来的 torch.Generator，**必须用它** ——
    #     否则同一 seed 不可复现，实验之间无法对比
    #   * 温度很高（>1.5）时分布接近均匀、容易"跑偏"；
    #     温度很低（<0.3）时容易复读。扫温度画"复读率 vs 跑偏率"曲线
    #     是 docs/03_思考题.md 第 6 题
    #   * top_k 的有效范围要 clamp 到 V，别让 topk 报错
    if temperature < 0:
        raise ValueError("temperature 不能为负数")
    if temperature == 0:
        return logits.argmax(dim=-1, keepdim=True)
    scores = logits.float() / temperature
    if top_k is not None and top_k > 0:
        k = min(top_k, scores.size(-1))
        threshold = scores.topk(k, dim=-1).values[:, -1:]
        scores = scores.masked_fill(scores < threshold, float("-inf"))
    return torch.multinomial(F.softmax(scores, dim=-1), 1, generator=rng)
# -----------------------------------------------------------------------------

class RowState:
    # Per-row state tracking during generation
    def __init__(self, current_tokens=None):
        self.current_tokens = current_tokens or [] # Current token sequence for this row
        self.forced_tokens = deque() # Queue of tokens to force inject
        self.in_python_block = False # Whether we are inside a python block
        self.python_expr_tokens = [] # Tokens of the current python expression
        self.completed = False # Whether this row has completed generation

class Engine:

    def __init__(self, model, tokenizer):
        self.model = model
        self.tokenizer = tokenizer # needed for tool use

    @torch.inference_mode()
    def generate(self, tokens, num_samples=1, max_tokens=None, temperature=1.0, top_k=None, seed=42):
        """Same as generate, but does single prefill and then clones the KV cache."""
        # ---- 核心任务 5：流式生成主循环（Engine.generate）----------------------
        # 这是一个 **generator**：每次 yield (token_column, token_masks)，
        #   token_column: (num_samples,) 本次每行产生的 token
        #   token_masks:  (num_samples,) 该 token 是否算作"助手输出"
        # （掩码用于 SFT 时只对助手部分算损失，推理阶段通常全为 1）
        #
        # 要点：
        #   1) **prefill 一次再克隆**：第一轮把整段 prompt 喂进去算出 KV cache，
        #      然后用你自己写的 KVCache.prefill 复制成 num_samples 份。
        #      之后每个采样步只喂**一个** token（Tq == 1），这是推理效率的关键
        #   2) 行状态（RowState）：某行采到结束标记后标记为 completed，
        #      后续步不再为它生成（但仍要凑齐 token_column 的长度）
        #   3) 滑窗：每层有自己的 window_size（GPT._compute_window_sizes 已写好），
        #      推理时把它与 kv_cache 一起传给注意力
        #   4) 采样用 sample_next_token（基础任务 4）
        #
        # 建议的推进顺序（这段代码比较长，别想一次写对）：
        #   先跑通 batch=1、num_samples=1、不带滑窗；再加批量；最后加窗口。
        #   参考 GPT.generate —— 那是更慢但更直白的实现，先写它更容易建立信心。
        if not tokens or num_samples < 1:
            raise ValueError("需要非空 prompt，且 num_samples 至少为 1")
        if max_tokens is not None and max_tokens <= 0:
            return
        cfg = self.model.config
        capacity = self.model.rotary_seq_len
        available = capacity - len(tokens) + 1
        if available <= 0:
            raise ValueError("prompt 超出模型 RoPE 表范围")
        limit = available if max_tokens is None else min(max_tokens, available)
        cache_len = len(tokens) + limit - 1
        device = self.model.get_device()
        dtype = COMPUTE_DTYPE
        rng = torch.Generator(device=device).manual_seed(seed)
        head_dim = cfg.n_embd // cfg.n_head
        prefill_cache = KVCache(1, cfg.n_kv_head, cache_len, head_dim, cfg.n_layer, device, dtype)
        idx = torch.tensor([tokens], device=device, dtype=torch.long)
        logits = self.model(idx, kv_cache=prefill_cache)[:, -1, :]
        cache = KVCache(num_samples, cfg.n_kv_head, cache_len, head_dim, cfg.n_layer, device, dtype)
        cache.prefill(prefill_cache)
        del prefill_cache
        logits = logits.expand(num_samples, -1)
        assistant_end = self.tokenizer.encode_special("<|assistant_end|>")
        bos = self.tokenizer.get_bos_token_id()
        rows = [RowState(tokens.copy()) for _ in range(num_samples)]

        for step in range(limit):
            active = [i for i, row in enumerate(rows) if not row.completed]
            sampled = sample_next_token(logits[active], rng, temperature, top_k).flatten().tolist()
            token_column = [assistant_end] * num_samples
            token_masks = [0] * num_samples
            for row_idx, token in zip(active, sampled):
                token_column[row_idx] = token
                token_masks[row_idx] = 1
                rows[row_idx].current_tokens.append(token)
                rows[row_idx].completed = token in (assistant_end, bos)
            yield token_column, token_masks
            if all(row.completed for row in rows) or step + 1 == limit:
                break
            idx = torch.tensor(token_column, device=device, dtype=torch.long).unsqueeze(1)
            logits = self.model(idx, kv_cache=cache)[:, -1, :]
    def generate_batch(self, tokens, num_samples=1, **kwargs):
        """
        Non-streaming batch generation that just returns the final token sequences.
        Returns a list of token sequences (list of lists of ints).
        Terminal tokens (assistant_end, bos) are not included in the results.
        """
        assistant_end = self.tokenizer.encode_special("<|assistant_end|>")
        bos = self.tokenizer.get_bos_token_id()
        results = [tokens.copy() for _ in range(num_samples)]
        masks = [[0] * len(tokens) for _ in range(num_samples)]
        completed = [False] * num_samples
        for token_column, token_masks in self.generate(tokens, num_samples, **kwargs):
            for i, (token, mask) in enumerate(zip(token_column, token_masks)):
                if not completed[i]:
                    if token == assistant_end or token == bos:
                        completed[i] = True
                    else:
                        results[i].append(token)
                        masks[i].append(mask)
            # Stop if all rows are completed
            if all(completed):
                break
        return results, masks


if __name__ == "__main__":
    """
    Quick inline test to make sure that the naive/slow model.generate function
    is equivalent to the faster Engine.generate function here.
    """
    import time
    from nanochat.checkpoint_manager import load_model
    # init compute
    device_type = autodetect_device_type()
    ddp, ddp_rank, ddp_local_rank, ddp_world_size, device = compute_init(device_type)
    # load the model and tokenizer
    model, tokenizer, meta = load_model("base", device, phase="eval")
    bos_token_id = tokenizer.get_bos_token_id()
    # common hyperparameters
    kwargs = dict(max_tokens=64, temperature=0.0)
    # set the starting prompt
    prompt_tokens = tokenizer.encode("The chemical formula of water is", prepend=bos_token_id)
    # generate the reference sequence using the model.generate() function
    generated_tokens = []
    torch.cuda.synchronize()
    t0 = time.time()
    stream = model.generate(prompt_tokens, **kwargs)
    for token in stream:
        generated_tokens.append(token)
        chunk = tokenizer.decode([token])
        print(chunk, end="", flush=True)
    print()
    torch.cuda.synchronize()
    t1 = time.time()
    print(f"Reference time: {t1 - t0:.2f}s")
    reference_ids = generated_tokens
    # generate tokens with Engine
    generated_tokens = []
    engine = Engine(model, tokenizer)
    stream = engine.generate(prompt_tokens, num_samples=1, **kwargs) # note: runs in fp32
    torch.cuda.synchronize()
    t0 = time.time()
    for token_column, token_masks in stream:
        token = token_column[0] # only print out the first row
        generated_tokens.append(token)
        chunk = tokenizer.decode([token])
        print(chunk, end="", flush=True)
    print()
    torch.cuda.synchronize()
    t1 = time.time()
    print(f"Engine time: {t1 - t0:.2f}s")
    # compare the two sequences
    for i in range(len(reference_ids)):
        if reference_ids[i] != generated_tokens[i]:
            print(f"Mismatch at {i}: {reference_ids[i]} != {generated_tokens[i]}")
            break
    print(f"Match: {reference_ids == generated_tokens}")
