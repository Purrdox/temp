"""CPU regressions for fill-ins not fully exercised by scripts/selfcheck.py."""
import math
import os
import unittest
from unittest.mock import patch

os.environ["NANOCHAT_DTYPE"] = "float32"

import torch

from nanochat import flash_attention as attention
from nanochat import gpt
from nanochat.engine import Engine, KVCache


class TinyTokenizer:
    def get_bos_token_id(self):
        return 65

    def encode_special(self, name):
        assert name == "<|assistant_end|>"
        return 66


def make_model():
    cfg = gpt.GPTConfig(sequence_len=512, vocab_size=67, n_layer=2,
                        n_head=2, n_kv_head=1, n_embd=64)
    model = gpt.GPT(cfg).eval()
    model.init_weights()
    # Nonzero output projections and smear expose cache bugs hidden by zero init.
    with torch.no_grad():
        for block in model.transformer.h:
            block.attn.c_proj.weight.normal_(std=0.04)
            block.mlp.c_proj.weight.normal_(std=0.04)
        model.smear_lambda.fill_(0.4)
        model.lm_head.weight[65:].zero_()
    return model


class FillinTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(1)

    def setUp(self):
        torch.manual_seed(2026)

    def test_chunked_gqa_attention_outputs_and_gradients(self):
        q = torch.randn(1, 4, 3, 8, requires_grad=True)
        k = torch.randn(1, 2, 9, 8, requires_grad=True)
        v = torch.randn(1, 2, 9, 8, requires_grad=True)
        got = attention._sdpa_attention(q, k, v, (2, 0), True)
        # Independent per-query definition: absolute query positions are 6,7,8.
        keys = k.double().repeat_interleave(2, dim=1)
        vals = v.double().repeat_interleave(2, dim=1)
        rows = []
        for i, position in enumerate((6, 7, 8)):
            lo, hi = position - 2, position + 1
            scores = (q[:, :, i:i + 1].double() @ keys[:, :, lo:hi].transpose(-1, -2)) / math.sqrt(8)
            rows.append(scores.softmax(-1) @ vals[:, :, lo:hi])
        want = torch.cat(rows, dim=2).float()
        torch.testing.assert_close(got, want, atol=1e-6, rtol=1e-5)
        probe = torch.randn_like(got)
        grad_got = torch.autograd.grad((got * probe).sum(), (q, k, v), retain_graph=True)
        grad_want = torch.autograd.grad((want * probe).sum(), (q, k, v))
        for actual, expected in zip(grad_got, grad_want):
            torch.testing.assert_close(actual, expected, atol=2e-6, rtol=1e-5)

    def test_public_noncausal_attention_and_cache(self):
        q, k, v = (torch.randn(1, 7, 2, 8) for _ in range(3))
        weights = (q.transpose(1, 2).double() @ k.transpose(1, 2).double().transpose(-1, -2)) / math.sqrt(8)
        want = (weights.softmax(-1) @ v.transpose(1, 2).double()).transpose(1, 2).float()
        got = attention.flash_attn_func(q, k, v, causal=False)
        kc, vc = torch.zeros_like(k), torch.zeros_like(v)
        cached = attention.flash_attn_with_kvcache(
            q, kc, vc, k, v, torch.tensor([0]), causal=False)
        torch.testing.assert_close(got, want, atol=1e-6, rtol=1e-5)
        torch.testing.assert_close(cached, want, atol=1e-6, rtol=1e-5)

    def test_model_chunk_cache_crosses_window_with_smear(self):
        model = make_model()
        idx = torch.randint(0, 65, (1, 140))
        cache = KVCache(1, 1, 140, 32, 2, torch.device("cpu"), torch.float32)
        with torch.no_grad():
            full = model(idx)
            parts, start = [], 0
            for length in (1, 5, 127, 7):
                parts.append(model(idx[:, start:start + length], kv_cache=cache))
                start += length
            chunked = torch.cat(parts, dim=1)
        self.assertEqual(cache.get_pos(), 140)
        torch.testing.assert_close(chunked, full, atol=3e-5, rtol=1e-4)

    def test_generation_matches_naive_and_prefills_once(self):
        model = make_model()
        prompt = [3, 7, 11, 19]
        reference = list(model.generate(prompt, 8, temperature=0))
        with patch.object(model, "forward", wraps=model.forward) as calls:
            streams, masks = Engine(model, TinyTokenizer()).generate_batch(
                prompt, num_samples=3, max_tokens=8, temperature=0)
        self.assertEqual(streams, [prompt + reference] * 3)
        self.assertEqual(masks, [[0] * len(prompt) + [1] * 8] * 3)
        self.assertEqual(tuple(calls.call_args_list[0].args[0].shape), (1, len(prompt)))
        self.assertEqual(len(calls.call_args_list), 8)
        for call in calls.call_args_list[1:]:
            self.assertEqual(tuple(call.args[0].shape), (3, 1))
        self.assertEqual(prompt, [3, 7, 11, 19])

    def test_generation_handles_rows_finishing_at_different_steps(self):
        model = make_model()
        samples = [torch.tensor([[66], [5], [6]]), torch.tensor([[7], [65]]), torch.tensor([[66]])]
        with patch("nanochat.engine.sample_next_token", side_effect=samples) as sampler:
            stream = list(Engine(model, TinyTokenizer()).generate(
                [3, 7], num_samples=3, max_tokens=8))
        self.assertEqual(stream, [([66, 5, 6], [1, 1, 1]),
                                  ([66, 7, 65], [0, 1, 1]),
                                  ([66, 66, 66], [0, 1, 0])])
        self.assertEqual([call.args[0].size(0) for call in sampler.call_args_list], [3, 2, 1])

    def test_prefill_copies_smear_and_keeps_rows_independent(self):
        source = KVCache(1, 1, 8, 4, 2, "cpu", torch.float32)
        target = KVCache(3, 1, 10, 4, 2, "cpu", torch.float32)
        source.k_cache.normal_()
        source.v_cache.normal_()
        source.prev_embedding = torch.randn(1, 1, 8)
        source.advance(3)
        target.prefill(source)
        torch.testing.assert_close(target.prev_embedding, source.prev_embedding.expand(3, -1, -1))
        original = source.k_cache[:, 0, :3].clone()
        target.k_cache[:, 0, :3].zero_()
        target.prev_embedding[0].zero_()
        torch.testing.assert_close(target.k_cache[:, 1, :3], original)
        torch.testing.assert_close(source.k_cache[:, 0, :3], original)
        torch.testing.assert_close(target.prev_embedding[1], source.prev_embedding[0])

    def test_npu_mask_and_call_wiring_only(self):
        # Mock verifies adapter arguments, NOT NPU numerical correctness/performance.
        env = {k: v for k, v in os.environ.items() if not k.startswith("NANOCHAT_NPU_FA_")}
        with patch.dict(os.environ, env, clear=True):
            mask = attention._npu_causal_mask(16, "cpu")
            self.assertEqual(tuple(mask.shape), (2048, 2048))
            self.assertFalse(bool(mask[3, 3]))
            self.assertTrue(bool(mask[3, 4]))
            self.assertFalse(bool(mask[4, 3]))
            self.assertEqual(mask.data_ptr(), attention._npu_causal_mask(8, "cpu").data_ptr())
            with self.assertRaises(ValueError):
                attention._npu_causal_mask(2049, "cpu")
            q, k, v = (torch.randn(1, 16, 2, 8) for _ in range(3))
            with patch.object(attention, "_npu_fa", return_value=(q,)) as fused:
                attention._npu_attention(q, k, v, (4, 0))
                args = fused.call_args.kwargs
                self.assertEqual((args["input_layout"], args["head_num"]), ("BSND", 2))
                self.assertEqual((args["sparse_mode"], args["pre_tockens"], args["next_tockens"]), (4, 4, 0))
                attention._npu_attention(q, k, v, (-1, 0))
                self.assertEqual(fused.call_args.kwargs["sparse_mode"], 2)

    def test_npu_rms_wiring_only(self):
        x = torch.randn(2, 3, 8)
        with patch.dict(gpt._NPU_RMS_STATE, {"resolved": True, "fn": None}):
            reference = gpt.norm(x)
        with patch.dict(gpt._NPU_RMS_STATE, {"resolved": True, "fn": lambda t, w, epsilon: (
                torch.nn.functional.rms_norm(t, (8,), weight=w, eps=epsilon),)}):
            actual = gpt.norm(x)
        torch.testing.assert_close(actual, reference)


if __name__ == "__main__":
    unittest.main()
