# AICS lab 2 private transfer

This snapshot transfers coursework to CANNLab. Work in `assign/`.

The included small public-domain parquet is for pipeline checks only. Formal data, model weights, logs, Python environments and credentials are excluded.

NPU baseline: `cd assign && PYTHON=python3 bash runs/train_npu.sh`. Existing CANN/PyTorch/torch_npu are reused; install the missing pyarrow/tiktoken dependencies first.
